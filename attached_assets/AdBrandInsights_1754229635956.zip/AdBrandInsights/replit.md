# Overview

This is a React-based advertising analytics dashboard called "ADmyBRAND Insights" that provides real-time monitoring and management of advertising campaigns. The application features a modern, responsive design with comprehensive data visualization, metrics tracking, and campaign management capabilities. It uses a full-stack TypeScript architecture with Express.js backend and React frontend, styled with Tailwind CSS and shadcn/ui components.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **UI Framework**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and dark/light theme support
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Charts**: Recharts library for data visualization (line charts, bar charts, pie charts)
- **Animations**: Framer Motion for smooth UI interactions
- **Layout**: Responsive design with mobile-first approach using CSS Grid and Flexbox

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Error Handling**: Centralized error middleware with proper HTTP status codes
- **Logging**: Custom request/response logging middleware
- **Development**: Hot module replacement via Vite integration

## Data Storage Solutions
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (configured via Neon serverless)
- **Schema**: Type-safe database schema with Zod validation
- **Migrations**: Drizzle Kit for database migrations
- **Fallback Storage**: In-memory storage implementation for development/testing

## Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL session store (connect-pg-simple)
- **Security**: No explicit authentication implementation in current codebase (appears to be development-focused)

## External Dependencies
- **Database**: Neon serverless PostgreSQL
- **Development Tools**: Replit-specific plugins for development environment
- **Export Capabilities**: PDF generation (jsPDF) and CSV export functionality
- **Real-time Updates**: Custom hooks for simulating real-time metrics updates

## Key Design Patterns
- **Component Architecture**: Modular component structure with clear separation of concerns
- **Data Flow**: Unidirectional data flow using React Query for server state
- **Theme System**: CSS custom properties for consistent theming across light/dark modes
- **Type Safety**: Full TypeScript coverage with shared types between frontend and backend
- **Responsive Design**: Mobile-first approach with progressive enhancement
- **Error Boundaries**: Graceful error handling with user-friendly fallbacks