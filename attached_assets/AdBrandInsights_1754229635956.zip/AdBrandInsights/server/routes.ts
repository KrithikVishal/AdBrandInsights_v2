import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCampaignSchema, insertMetricsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all campaigns
  app.get("/api/campaigns", async (req, res) => {
    try {
      const campaigns = await storage.getCampaigns();
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  // Get single campaign
  app.get("/api/campaigns/:id", async (req, res) => {
    try {
      const campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      res.json(campaign);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch campaign" });
    }
  });

  // Create new campaign
  app.post("/api/campaigns", async (req, res) => {
    try {
      const validatedData = insertCampaignSchema.parse(req.body);
      const campaign = await storage.createCampaign(validatedData);
      res.status(201).json(campaign);
    } catch (error) {
      res.status(400).json({ message: "Invalid campaign data" });
    }
  });

  // Update campaign
  app.patch("/api/campaigns/:id", async (req, res) => {
    try {
      const partialData = insertCampaignSchema.partial().parse(req.body);
      const campaign = await storage.updateCampaign(req.params.id, partialData);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      res.json(campaign);
    } catch (error) {
      res.status(400).json({ message: "Invalid campaign data" });
    }
  });

  // Delete campaign
  app.delete("/api/campaigns/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCampaign(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete campaign" });
    }
  });

  // Get latest metrics
  app.get("/api/metrics", async (req, res) => {
    try {
      const metrics = await storage.getLatestMetrics();
      if (!metrics) {
        return res.status(404).json({ message: "No metrics found" });
      }
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // Get metrics history
  app.get("/api/metrics/history", async (req, res) => {
    try {
      const history = await storage.getMetricsHistory();
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch metrics history" });
    }
  });

  // Create new metrics
  app.post("/api/metrics", async (req, res) => {
    try {
      const validatedData = insertMetricsSchema.parse(req.body);
      const metrics = await storage.createMetrics(validatedData);
      res.status(201).json(metrics);
    } catch (error) {
      res.status(400).json({ message: "Invalid metrics data" });
    }
  });

  // Get traffic sources
  app.get("/api/traffic-sources", async (req, res) => {
    try {
      const sources = await storage.getTrafficSources();
      res.json(sources);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch traffic sources" });
    }
  });

  // Get chart data for revenue trend
  app.get("/api/charts/revenue-trend", async (req, res) => {
    try {
      // Generate mock revenue trend data
      const data = [
        { month: "Jan", revenue: 65000 },
        { month: "Feb", revenue: 75000 },
        { month: "Mar", revenue: 82000 },
        { month: "Apr", revenue: 78000 },
        { month: "May", revenue: 90000 },
        { month: "Jun", revenue: 88000 },
        { month: "Jul", revenue: 95000 },
      ];
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch revenue trend data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
