import { type Campaign, type InsertCampaign, type Metrics, type InsertMetrics, type TrafficSource, type InsertTrafficSource } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Campaigns
  getCampaigns(): Promise<Campaign[]>;
  getCampaign(id: string): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: string, campaign: Partial<InsertCampaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: string): Promise<boolean>;
  
  // Metrics
  getLatestMetrics(): Promise<Metrics | undefined>;
  getMetricsHistory(): Promise<Metrics[]>;
  createMetrics(metrics: InsertMetrics): Promise<Metrics>;
  
  // Traffic Sources
  getTrafficSources(): Promise<TrafficSource[]>;
  createTrafficSource(source: InsertTrafficSource): Promise<TrafficSource>;
}

export class MemStorage implements IStorage {
  private campaigns: Map<string, Campaign>;
  private metrics: Map<string, Metrics>;
  private trafficSources: Map<string, TrafficSource>;

  constructor() {
    this.campaigns = new Map();
    this.metrics = new Map();
    this.trafficSources = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize campaigns
    const sampleCampaigns: Campaign[] = [
      {
        id: "1",
        name: "Summer Sale 2024",
        type: "Google Ads",
        status: "Active",
        impressions: 847392,
        clicks: 12483,
        ctr: "1.47",
        cost: "2847.00",
        createdAt: new Date(),
        isActive: true,
      },
      {
        id: "2",
        name: "Brand Awareness Q3",
        type: "Facebook Ads",
        status: "Paused",
        impressions: 523847,
        clicks: 8294,
        ctr: "1.58",
        cost: "1923.00",
        createdAt: new Date(),
        isActive: true,
      },
      {
        id: "3",
        name: "Product Launch",
        type: "LinkedIn Ads",
        status: "Running",
        impressions: 294582,
        clicks: 6847,
        ctr: "2.32",
        cost: "3294.00",
        createdAt: new Date(),
        isActive: true,
      },
      {
        id: "4",
        name: "Retargeting Campaign",
        type: "Google Display",
        status: "Ended",
        impressions: 638294,
        clicks: 9847,
        ctr: "1.54",
        cost: "2439.00",
        createdAt: new Date(),
        isActive: true,
      },
    ];

    sampleCampaigns.forEach(campaign => {
      this.campaigns.set(campaign.id, campaign);
    });

    // Initialize metrics
    const currentMetrics: Metrics = {
      id: "1",
      date: new Date(),
      revenue: "847932.00",
      users: 24563,
      conversions: 3247,
      growthRate: "43.20",
    };
    this.metrics.set(currentMetrics.id, currentMetrics);

    // Initialize traffic sources
    const trafficSources: TrafficSource[] = [
      { id: "1", source: "Google Ads", percentage: "35.00", color: "#6366f1" },
      { id: "2", source: "Facebook", percentage: "25.00", color: "#8b5cf6" },
      { id: "3", source: "LinkedIn", percentage: "20.00", color: "#ec4899" },
      { id: "4", source: "Direct", percentage: "15.00", color: "#10b981" },
      { id: "5", source: "Other", percentage: "5.00", color: "#f59e0b" },
    ];

    trafficSources.forEach(source => {
      this.trafficSources.set(source.id, source);
    });
  }

  async getCampaigns(): Promise<Campaign[]> {
    return Array.from(this.campaigns.values());
  }

  async getCampaign(id: string): Promise<Campaign | undefined> {
    return this.campaigns.get(id);
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = randomUUID();
    const campaign: Campaign = {
      id,
      name: insertCampaign.name,
      type: insertCampaign.type,
      status: insertCampaign.status,
      impressions: insertCampaign.impressions || 0,
      clicks: insertCampaign.clicks || 0,
      ctr: insertCampaign.ctr || "0",
      cost: insertCampaign.cost || "0",
      createdAt: new Date(),
      isActive: insertCampaign.isActive ?? true,
    };
    this.campaigns.set(id, campaign);
    return campaign;
  }

  async updateCampaign(id: string, updateData: Partial<InsertCampaign>): Promise<Campaign | undefined> {
    const campaign = this.campaigns.get(id);
    if (!campaign) return undefined;

    const updatedCampaign = { ...campaign, ...updateData };
    this.campaigns.set(id, updatedCampaign);
    return updatedCampaign;
  }

  async deleteCampaign(id: string): Promise<boolean> {
    return this.campaigns.delete(id);
  }

  async getLatestMetrics(): Promise<Metrics | undefined> {
    const metricsArray = Array.from(this.metrics.values());
    return metricsArray.sort((a, b) => new Date(b.date!).getTime() - new Date(a.date!).getTime())[0];
  }

  async getMetricsHistory(): Promise<Metrics[]> {
    return Array.from(this.metrics.values());
  }

  async createMetrics(insertMetrics: InsertMetrics): Promise<Metrics> {
    const id = randomUUID();
    const metrics: Metrics = {
      ...insertMetrics,
      id,
      date: new Date(),
    };
    this.metrics.set(id, metrics);
    return metrics;
  }

  async getTrafficSources(): Promise<TrafficSource[]> {
    return Array.from(this.trafficSources.values());
  }

  async createTrafficSource(insertSource: InsertTrafficSource): Promise<TrafficSource> {
    const id = randomUUID();
    const source: TrafficSource = {
      ...insertSource,
      id,
    };
    this.trafficSources.set(id, source);
    return source;
  }
}

export const storage = new MemStorage();
