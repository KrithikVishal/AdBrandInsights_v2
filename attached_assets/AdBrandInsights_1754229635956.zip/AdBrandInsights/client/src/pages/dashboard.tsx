import { useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { MetricsCards } from "@/components/dashboard/metrics-cards";
import { ChartsSection } from "@/components/dashboard/charts-section";
import { DataTable } from "@/components/dashboard/data-table";
import { PredictiveAnalytics } from "@/components/dashboard/predictive-analytics";
import { InsightFeed } from "@/components/dashboard/insight-feed";
import { InteractiveFilters, FilterTrigger } from "@/components/dashboard/interactive-filters";
import { ThemeSelector, ThemeTrigger } from "@/components/dashboard/theme-selector";
import { ExportManager, ExportTrigger } from "@/components/dashboard/export-manager";
import { ToastManager, Toast } from "@/components/ui/toast-notification";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export default function Dashboard() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [filterCount, setFilterCount] = useState(0);
  const [isThemeSelectorOpen, setIsThemeSelectorOpen] = useState(false);
  const [isExportManagerOpen, setIsExportManagerOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = (toast: Toast) => {
    setToasts(prev => [...prev, toast]);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-slate-900">
      {/* Desktop Sidebar */}
      <Sidebar className="hidden lg:block" />
      
      {/* Mobile Sidebar */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetContent side="left" className="p-0 w-64">
          <Sidebar />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        <Header onMobileMenuToggle={() => setIsMobileMenuOpen(true)} />
        
        <div className="p-6 space-y-8 overflow-y-auto max-h-[calc(100vh-88px)]">
          {/* Action Bar */}
          <motion.div 
            className="flex justify-between items-center"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center space-x-3">
              <ThemeTrigger onOpen={() => setIsThemeSelectorOpen(true)} />
              <ExportTrigger onOpen={() => setIsExportManagerOpen(true)} />
            </div>
            <FilterTrigger onOpen={() => setIsFiltersOpen(true)} filterCount={filterCount} />
          </motion.div>

          {/* Main Dashboard Content */}
          <div className="grid grid-cols-12 gap-8" data-dashboard-content>
            {/* Left Column - Main Metrics & Analytics */}
            <div className="col-span-12 lg:col-span-8 space-y-8">
              <MetricsCards />
              <PredictiveAnalytics />
              <ChartsSection />
              <DataTable />
            </div>

            {/* Right Column - Insights Feed */}
            <div className="col-span-12 lg:col-span-4">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 }}
              >
                <InsightFeed />
              </motion.div>
            </div>
          </div>

          {/* Interactive Filters Panel */}
          <InteractiveFilters 
            isOpen={isFiltersOpen} 
            onClose={() => setIsFiltersOpen(false)}
            onFiltersChange={(filters) => {
              const count = filters.campaignTypes.length + filters.geography.length + filters.devices.length;
              setFilterCount(count);
            }}
          />

          {/* Theme Selector */}
          <ThemeSelector
            isOpen={isThemeSelectorOpen}
            onClose={() => setIsThemeSelectorOpen(false)}
            onThemeChange={(themeId) => {
              addToast({
                id: `theme-${Date.now()}`,
                type: "success",
                title: "Theme Applied!",
                description: `Your dashboard is now using the ${themeId} theme.`,
                duration: 3000
              });
            }}
          />

          {/* Export Manager */}
          <ExportManager
            isOpen={isExportManagerOpen}
            onClose={() => setIsExportManagerOpen(false)}
            onShowToast={addToast}
          />

          {/* Toast Notifications */}
          <ToastManager
            toasts={toasts}
            onDismiss={removeToast}
          />
        </div>
      </main>
    </div>
  );
}
