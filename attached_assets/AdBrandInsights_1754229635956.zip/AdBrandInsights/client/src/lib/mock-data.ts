export const generateRevenueData = () => {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];
  return months.map(month => ({
    month,
    revenue: Math.floor(Math.random() * 30000) + 65000,
  }));
};

export const generateCampaignData = () => {
  const campaigns = ["Summer Sale", "Brand Awareness", "Product Launch", "Retargeting", "Holiday Campaign"];
  return campaigns.map(campaign => ({
    campaign,
    ctr: (Math.random() * 2 + 1).toFixed(2),
  }));
};

export const trafficSourcesData = [
  { source: "Google Ads", percentage: 35, color: "#6366f1" },
  { source: "Facebook", percentage: 25, color: "#8b5cf6" },
  { source: "LinkedIn", percentage: 20, color: "#ec4899" },
  { source: "Direct", percentage: 15, color: "#10b981" },
  { source: "Other", percentage: 5, color: "#f59e0b" },
];

export const updateMetricsWithVariation = (baseValue: number, variation: number = 0.02) => {
  const change = (Math.random() - 0.5) * variation;
  return Math.round(baseValue * (1 + change));
};
