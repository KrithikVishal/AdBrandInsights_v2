import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface LoadingSkeletonProps {
  className?: string;
  variant?: "card" | "text" | "avatar" | "button";
  animate?: boolean;
}

export function LoadingSkeleton({ 
  className, 
  variant = "card",
  animate = true 
}: LoadingSkeletonProps) {
  const baseClasses = "bg-gray-200 dark:bg-slate-700 rounded-lg";
  
  const variants = {
    card: "h-32 w-full",
    text: "h-4 w-3/4",
    avatar: "h-10 w-10 rounded-full",
    button: "h-10 w-24"
  };

  const Component = animate ? motion.div : "div";
  
  const animationProps = animate ? {
    animate: {
      opacity: [0.4, 0.8, 0.4],
    },
    transition: {
      duration: 1.5,
      repeat: Infinity,
      ease: "easeInOut"
    }
  } : {};

  return (
    <Component 
      className={cn(
        baseClasses,
        variants[variant],
        "animate-shimmer",
        className
      )}
      {...animationProps}
    />
  );
}