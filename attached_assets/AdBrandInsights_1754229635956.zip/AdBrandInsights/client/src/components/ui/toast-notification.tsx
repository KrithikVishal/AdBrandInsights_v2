import { motion, AnimatePresence } from "framer-motion";
import { X, CheckCircle, AlertCircle, Info, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

export interface Toast {
  id: string;
  type: "success" | "error" | "info" | "suggestion";
  title: string;
  description: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

interface ToastNotificationProps {
  toast: Toast;
  onDismiss: (id: string) => void;
}

const toastIcons = {
  success: CheckCircle,
  error: AlertCircle,
  info: Info,
  suggestion: Lightbulb,
};

const toastColors = {
  success: "from-green-500 to-emerald-600",
  error: "from-red-500 to-rose-600",
  info: "from-blue-500 to-indigo-600",
  suggestion: "from-purple-500 to-violet-600",
};

export function ToastNotification({ toast, onDismiss }: ToastNotificationProps) {
  const [isVisible, setIsVisible] = useState(true);
  const Icon = toastIcons[toast.type];

  useEffect(() => {
    if (toast.duration) {
      const timer = setTimeout(() => {
        setIsVisible(false);
        setTimeout(() => onDismiss(toast.id), 300);
      }, toast.duration);

      return () => clearTimeout(timer);
    }
  }, [toast.duration, toast.id, onDismiss]);

  const handleDismiss = () => {
    setIsVisible(false);
    setTimeout(() => onDismiss(toast.id), 300);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, x: 300, scale: 0.9 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: 300, scale: 0.9 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="relative max-w-sm w-full bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-gray-200 dark:border-slate-700 overflow-hidden group"
        >
          {/* Gradient border */}
          <div className={`absolute inset-0 bg-gradient-to-r ${toastColors[toast.type]} opacity-0 group-hover:opacity-20 transition-opacity duration-300`} />
          
          <div className="p-4">
            <div className="flex items-start space-x-3">
              <motion.div
                className={`p-2 rounded-lg bg-gradient-to-r ${toastColors[toast.type]} text-white`}
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
              >
                <Icon className="w-4 h-4" />
              </motion.div>
              
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-gray-900 dark:text-white text-sm">
                  {toast.title}
                </h4>
                <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">
                  {toast.description}
                </p>
                
                {toast.action && (
                  <motion.div 
                    className="mt-3"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <Button
                      size="sm"
                      onClick={toast.action.onClick}
                      className={`bg-gradient-to-r ${toastColors[toast.type]} hover:opacity-90 text-white`}
                    >
                      {toast.action.label}
                    </Button>
                  </motion.div>
                )}
              </div>
              
              <motion.button
                onClick={handleDismiss}
                className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <X className="w-4 h-4 text-gray-500 dark:text-gray-400" />
              </motion.button>
            </div>
          </div>
          
          {/* Progress bar for timed toasts */}
          {toast.duration && (
            <motion.div
              className={`h-1 bg-gradient-to-r ${toastColors[toast.type]}`}
              initial={{ width: "100%" }}
              animate={{ width: "0%" }}
              transition={{ duration: toast.duration / 1000, ease: "linear" }}
            />
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface ToastManagerProps {
  toasts: Toast[];
  onDismiss: (id: string) => void;
}

export function ToastManager({ toasts, onDismiss }: ToastManagerProps) {
  return (
    <div className="fixed top-4 right-4 z-50 space-y-3 max-w-sm">
      <AnimatePresence>
        {toasts.map((toast) => (
          <ToastNotification
            key={toast.id}
            toast={toast}
            onDismiss={onDismiss}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}