import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { TrendingUp, Target, Users, Zap, AlertTriangle } from "lucide-react";
import { useEffect, useState } from "react";
import { LineChart, Line, ResponsiveContainer, Area, AreaChart } from "recharts";

interface PredictiveMetric {
  id: string;
  title: string;
  prediction: number;
  confidence: number;
  trend: "up" | "down" | "stable";
  timeframe: string;
  sparkData: Array<{ value: number }>;
  icon: any;
  color: string;
  unit?: string;
}

const mockPredictiveData: PredictiveMetric[] = [
  {
    id: "conversions",
    title: "Expected Conversions",
    prediction: 4250,
    confidence: 87,
    trend: "up",
    timeframe: "Next Week",
    sparkData: [{ value: 3200 }, { value: 3400 }, { value: 3650 }, { value: 3900 }, { value: 4250 }],
    icon: Target,
    color: "from-green-400 to-emerald-600",
    unit: ""
  },
  {
    id: "churn",
    title: "Churn Prediction",
    prediction: 12.5,
    confidence: 73,
    trend: "down",
    timeframe: "Next Month",
    sparkData: [{ value: 15.2 }, { value: 14.1 }, { value: 13.8 }, { value: 13.2 }, { value: 12.5 }],
    icon: AlertTriangle,
    color: "from-red-400 to-rose-600",
    unit: "%"
  },
  {
    id: "revenue",
    title: "Revenue Forecast",
    prediction: 892000,
    confidence: 91,
    trend: "up",
    timeframe: "Next Quarter",
    sparkData: [{ value: 750000 }, { value: 780000 }, { value: 820000 }, { value: 850000 }, { value: 892000 }],
    icon: TrendingUp,
    color: "from-blue-400 to-indigo-600",
    unit: "$"
  },
  {
    id: "engagement",
    title: "User Engagement",
    prediction: 78.5,
    confidence: 82,
    trend: "up",
    timeframe: "This Week",
    sparkData: [{ value: 72 }, { value: 74 }, { value: 76 }, { value: 77 }, { value: 78.5 }],
    icon: Users,
    color: "from-purple-400 to-violet-600",
    unit: "%"
  }
];

export function PredictiveAnalytics() {
  const [predictions, setPredictions] = useState(mockPredictiveData);

  // Simulate real-time forecast updates
  useEffect(() => {
    const interval = setInterval(() => {
      setPredictions(prev => prev.map(prediction => ({
        ...prediction,
        prediction: prediction.prediction + (Math.random() - 0.5) * (prediction.prediction * 0.02),
        confidence: Math.max(60, Math.min(95, prediction.confidence + (Math.random() - 0.5) * 5)),
        sparkData: [
          ...prediction.sparkData.slice(1),
          { value: prediction.prediction + (Math.random() - 0.5) * (prediction.prediction * 0.05) }
        ]
      })));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center space-x-3"
      >
        <motion.div
          className="p-2 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-white"
          animate={{ rotate: [0, 5, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity, repeatDelay: 8 }}
        >
          <Zap className="w-5 h-5" />
        </motion.div>
        <div>
          <h2 className="text-xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
            Predictive Analytics
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-sm">
            AI-powered forecasts and predictions
          </p>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {predictions.map((prediction, index) => {
          const Icon = prediction.icon;
          
          return (
            <motion.div
              key={prediction.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1, type: "spring", stiffness: 100 }}
              whileHover={{ scale: 1.02, y: -4 }}
            >
              <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-white to-gray-50 dark:from-slate-800 dark:to-slate-900 hover:shadow-2xl transition-all duration-500 group">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <motion.div
                        className={`p-2 rounded-lg bg-gradient-to-r ${prediction.color} text-white`}
                        whileHover={{ rotate: 10, scale: 1.1 }}
                        transition={{ type: "spring", stiffness: 400 }}
                      >
                        <Icon className="w-4 h-4" />
                      </motion.div>
                      <div>
                        <CardTitle className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {prediction.title}
                        </CardTitle>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {prediction.timeframe}
                        </p>
                      </div>
                    </div>
                    
                    {/* Confidence Badge */}
                    <motion.div
                      className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        prediction.confidence > 85 
                          ? 'bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400'
                          : prediction.confidence > 75 
                          ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400'
                          : 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400'
                      }`}
                      animate={{ opacity: [0.8, 1, 0.8] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      {prediction.confidence}% confidence
                    </motion.div>
                  </div>
                </CardHeader>

                <CardContent className="pt-0">
                  {/* Prediction Value */}
                  <motion.div 
                    className="flex items-baseline space-x-2 mb-4"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 + 0.2 }}
                  >
                    <span className="text-2xl font-bold text-gray-900 dark:text-white">
                      {prediction.unit === '$' ? '$' : ''}
                      {prediction.unit === '$' 
                        ? Math.round(prediction.prediction).toLocaleString()
                        : prediction.prediction.toFixed(1)
                      }
                      {prediction.unit === '%' ? '%' : ''}
                    </span>
                    <motion.div
                      className={`flex items-center text-xs font-medium ${
                        prediction.trend === 'up' 
                          ? 'text-green-600 dark:text-green-400'
                          : prediction.trend === 'down'
                          ? 'text-red-600 dark:text-red-400'
                          : 'text-gray-600 dark:text-gray-400'
                      }`}
                      animate={{ x: [0, 2, 0] }}
                      transition={{ duration: 1, repeat: Infinity, repeatDelay: 3 }}
                    >
                      <TrendingUp className={`w-3 h-3 mr-1 ${prediction.trend === 'down' ? 'rotate-180' : ''}`} />
                      {prediction.trend}
                    </motion.div>
                  </motion.div>

                  {/* Spark Line Chart */}
                  <motion.div 
                    className="h-12 mb-2"
                    initial={{ opacity: 0, scaleX: 0 }}
                    animate={{ opacity: 1, scaleX: 1 }}
                    transition={{ delay: index * 0.1 + 0.4, duration: 0.8 }}
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={prediction.sparkData}>
                        <defs>
                          <linearGradient id={`gradient-${prediction.id}`} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={`hsl(${prediction.color.includes('green') ? '142' : prediction.color.includes('red') ? '0' : prediction.color.includes('blue') ? '214' : '262'}, 70%, 50%)`} stopOpacity={0.3}/>
                            <stop offset="95%" stopColor={`hsl(${prediction.color.includes('green') ? '142' : prediction.color.includes('red') ? '0' : prediction.color.includes('blue') ? '214' : '262'}, 70%, 50%)`} stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <Area 
                          type="monotone" 
                          dataKey="value" 
                          stroke={`hsl(${prediction.color.includes('green') ? '142' : prediction.color.includes('red') ? '0' : prediction.color.includes('blue') ? '214' : '262'}, 70%, 50%)`}
                          strokeWidth={2}
                          fill={`url(#gradient-${prediction.id})`}
                          dot={false}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </motion.div>

                  {/* Confidence Bar */}
                  <motion.div className="space-y-1">
                    <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                      <span>Confidence Level</span>
                      <span>{prediction.confidence}%</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 overflow-hidden">
                      <motion.div
                        className={`h-full bg-gradient-to-r ${prediction.color} rounded-full`}
                        initial={{ width: 0 }}
                        animate={{ width: `${prediction.confidence}%` }}
                        transition={{ delay: index * 0.1 + 0.6, duration: 1, ease: "easeOut" }}
                      />
                    </div>
                  </motion.div>
                </CardContent>

                {/* Animated background pattern */}
                <motion.div
                  className="absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-br from-primary/5 to-purple-500/5 rounded-full opacity-0 group-hover:opacity-100"
                  animate={{ 
                    rotate: 360,
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                    scale: { duration: 4, repeat: Infinity, ease: "easeInOut" }
                  }}
                />
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}