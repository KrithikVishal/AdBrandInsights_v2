import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import React from "react";
import { Brain, TrendingUp, TrendingDown, AlertCircle, Lightbulb, Target, Users, DollarSign } from "lucide-react";
import { useEffect, useState } from "react";

interface Insight {
  id: string;
  type: "success" | "warning" | "info" | "trend";
  title: string;
  description: string;
  timestamp: Date;
  metric?: string;
  change?: string;
  icon: any;
  color: string;
  priority: "high" | "medium" | "low";
}

const mockInsights: Insight[] = [
  {
    id: "1",
    type: "success",
    title: "Revenue Surge Detected",
    description: "Revenue up 12% from last week due to 'Summer Sale 2024' campaign. Consider extending the promotion.",
    timestamp: new Date(Date.now() - 2 * 60000),
    metric: "Revenue",
    change: "+12%",
    icon: TrendingUp,
    color: "from-green-500 to-emerald-600",
    priority: "high"
  },
  {
    id: "2",
    type: "warning",
    title: "User Activity Decline",
    description: "User activity dipped 18% during 2-4 PM. Consider targeting active hours with special offers.",
    timestamp: new Date(Date.now() - 5 * 60000),
    metric: "Engagement",
    change: "-18%",
    icon: AlertCircle,
    color: "from-orange-500 to-red-500",
    priority: "high"
  },
  {
    id: "3",
    type: "info",
    title: "Conversion Optimization",
    description: "Mobile users show 23% higher conversion rates. Consider mobile-first campaign strategies.",
    timestamp: new Date(Date.now() - 8 * 60000),
    metric: "Conversions",
    change: "+23%",
    icon: Target,
    color: "from-blue-500 to-indigo-600",
    priority: "medium"
  },
  {
    id: "4",
    type: "trend",
    title: "Audience Growth Pattern",
    description: "New user acquisition peaks on weekends. Schedule content for Friday-Sunday.",
    timestamp: new Date(Date.now() - 12 * 60000),
    metric: "Users",
    change: "+34%",
    icon: Users,
    color: "from-purple-500 to-violet-600",
    priority: "medium"
  },
  {
    id: "5",
    type: "success",
    title: "Cost Efficiency Improved",
    description: "Cost per acquisition decreased by 15% after optimizing ad targeting parameters.",
    timestamp: new Date(Date.now() - 15 * 60000),
    metric: "CPA",
    change: "-15%",
    icon: DollarSign,
    color: "from-teal-500 to-cyan-600",
    priority: "low"
  }
];

export function InsightFeed() {
  const [insights, setInsights] = useState(mockInsights);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto-scroll through insights
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % insights.length);
    }, 8000);

    return () => clearInterval(interval);
  }, [insights.length]);

  // Add new insights periodically
  useEffect(() => {
    const addNewInsight = () => {
      const newInsight: Insight = {
        id: `new-${Date.now()}`,
        type: ["success", "warning", "info", "trend"][Math.floor(Math.random() * 4)] as any,
        title: [
          "Campaign Performance Update",
          "Audience Behavior Shift",
          "Market Trend Alert",
          "Optimization Opportunity"
        ][Math.floor(Math.random() * 4)],
        description: [
          "Latest campaign shows promising early results with engagement up significantly.",
          "User behavior patterns indicate shift in peak activity hours.",
          "Industry benchmark comparison reveals competitive advantages.",
          "Machine learning detected optimization potential in current strategy."
        ][Math.floor(Math.random() * 4)],
        timestamp: new Date(),
        metric: ["Revenue", "Users", "Conversions", "Engagement"][Math.floor(Math.random() * 4)],
        change: `${Math.random() > 0.5 ? '+' : '-'}${Math.floor(Math.random() * 30)}%`,
        icon: [TrendingUp, Users, Target, Lightbulb][Math.floor(Math.random() * 4)],
        color: [
          "from-green-500 to-emerald-600",
          "from-blue-500 to-indigo-600", 
          "from-purple-500 to-violet-600",
          "from-orange-500 to-red-500"
        ][Math.floor(Math.random() * 4)],
        priority: ["high", "medium", "low"][Math.floor(Math.random() * 3)] as any
      };

      setInsights(prev => [newInsight, ...prev.slice(0, 9)]); // Keep only 10 most recent
    };

    const interval = setInterval(addNewInsight, 15000);
    return () => clearInterval(interval);
  }, []);

  const formatTimeAgo = (timestamp: Date) => {
    const minutes = Math.floor((Date.now() - timestamp.getTime()) / 60000);
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h ago`;
  };

  return (
    <Card className="h-[600px] border-0 bg-gradient-to-br from-white to-gray-50 dark:from-slate-800 dark:to-slate-900 overflow-hidden">
      <CardHeader className="pb-4">
        <motion.div 
          className="flex items-center space-x-3"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <motion.div
            className="p-2 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-white"
            animate={{ 
              rotate: [0, 10, -10, 0],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 3, 
              repeat: Infinity,
              repeatDelay: 5
            }}
          >
            <Brain className="w-5 h-5" />
          </motion.div>
          <div>
            <CardTitle className="text-lg font-semibold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
              AI Insights Feed
            </CardTitle>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Real-time analytics and recommendations
            </p>
          </div>
        </motion.div>
      </CardHeader>

      <CardContent className="p-0 h-[500px] overflow-hidden">
        <div className="relative h-full">
          {/* Featured Insight */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -50, scale: 0.9 }}
              transition={{ duration: 0.8, type: "spring", stiffness: 100 }}
              className="absolute inset-x-6 top-0"
            >
              {insights[currentIndex] && (
                <motion.div 
                  className="p-4 rounded-xl bg-gradient-to-r from-white/80 to-gray-50/80 dark:from-slate-700/80 dark:to-slate-800/80 backdrop-blur-sm border border-gray-200/50 dark:border-slate-600/50 mb-4"
                  whileHover={{ scale: 1.02, y: -2 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="flex items-start space-x-3">
                    <motion.div
                      className={`p-2 rounded-lg bg-gradient-to-r ${insights[currentIndex].color} text-white`}
                      animate={{ rotate: [0, 5, -5, 0] }}
                      transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                    >
                      {React.createElement(insights[currentIndex].icon, { className: "w-4 h-4" })}
                    </motion.div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {insights[currentIndex].title}
                        </h3>
                        <motion.span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            insights[currentIndex].priority === 'high' 
                              ? 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400'
                              : insights[currentIndex].priority === 'medium'
                              ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400'
                              : 'bg-gray-100 text-gray-700 dark:bg-gray-900/20 dark:text-gray-400'
                          }`}
                          animate={{ opacity: [0.7, 1, 0.7] }}
                          transition={{ duration: 2, repeat: Infinity }}
                        >
                          {insights[currentIndex].priority}
                        </motion.span>
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">
                        {insights[currentIndex].description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {insights[currentIndex].metric && (
                            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
                              {insights[currentIndex].metric}
                            </span>
                          )}
                          {insights[currentIndex].change && (
                            <motion.span
                              className={`text-xs font-bold ${
                                insights[currentIndex].change?.startsWith('+') 
                                  ? 'text-green-600 dark:text-green-400'
                                  : 'text-red-600 dark:text-red-400'
                              }`}
                              animate={{ scale: [1, 1.1, 1] }}
                              transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 4 }}
                            >
                              {insights[currentIndex].change}
                            </motion.span>
                          )}
                        </div>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {formatTimeAgo(insights[currentIndex].timestamp)}
                        </span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Scrolling Feed */}
          <div className="absolute inset-x-6 top-32 bottom-0 overflow-hidden">
            <motion.div 
              className="space-y-3 h-full overflow-y-auto scrollbar-hide"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              {insights.slice(1).map((insight, index) => (
                <motion.div
                  key={insight.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-3 rounded-lg bg-white/60 dark:bg-slate-700/60 backdrop-blur-sm border border-gray-200/30 dark:border-slate-600/30 hover:bg-white/80 dark:hover:bg-slate-700/80 transition-all duration-300 cursor-pointer group"
                  whileHover={{ scale: 1.01, x: 4 }}
                >
                  <div className="flex items-center space-x-3">
                    <motion.div
                      className={`p-1.5 rounded-md bg-gradient-to-r ${insight.color} text-white opacity-80 group-hover:opacity-100`}
                      whileHover={{ rotate: 10, scale: 1.1 }}
                    >
                      {React.createElement(insight.icon, { className: "w-3 h-3" })}
                    </motion.div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm text-gray-900 dark:text-white truncate">
                        {insight.title}
                      </h4>
                      <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-2">
                        {insight.description}
                      </p>
                      <div className="flex items-center justify-between mt-1">
                        <div className="flex items-center space-x-2">
                          {insight.change && (
                            <span className={`text-xs font-semibold ${
                              insight.change.startsWith('+') 
                                ? 'text-green-600 dark:text-green-400'
                                : 'text-red-600 dark:text-red-400'
                            }`}>
                              {insight.change}
                            </span>
                          )}
                        </div>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {formatTimeAgo(insight.timestamp)}
                        </span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Progress Indicator */}
          <motion.div 
            className="absolute bottom-4 left-6 right-6 flex space-x-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            {insights.slice(0, 5).map((_, index) => (
              <motion.div
                key={index}
                className={`h-1 rounded-full transition-all duration-300 ${
                  index === currentIndex 
                    ? 'bg-primary flex-1' 
                    : 'bg-gray-300 dark:bg-gray-600 w-8'
                }`}
                animate={index === currentIndex ? { scale: [1, 1.1, 1] } : {}}
                transition={{ duration: 0.5 }}
              />
            ))}
          </motion.div>
        </div>
      </CardContent>
    </Card>
  );
}