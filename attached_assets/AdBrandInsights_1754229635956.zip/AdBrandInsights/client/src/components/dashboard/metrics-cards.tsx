import { Card, CardContent } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { DollarSign, Users, Target, TrendingUp, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { useRealTimeMetrics } from "@/hooks/use-real-time";
import { AnimatedCounter } from "@/components/ui/animated-counter";
import { LoadingSkeleton } from "@/components/ui/loading-skeleton";

const metricIcons = {
  revenue: DollarSign,
  users: Users,
  conversions: Target,
  growth: TrendingUp,
};

const metricColors = {
  revenue: "text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/20",
  users: "text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/20",
  conversions: "text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/20",
  growth: "text-orange-600 dark:text-orange-400 bg-orange-100 dark:bg-orange-900/20",
};

export function MetricsCards() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/metrics"],
  });

  const realtimeMetrics = useRealTimeMetrics(
    metrics ? {
      revenue: `$${parseInt((metrics as any).revenue || "0").toLocaleString()}`,
      users: (metrics as any).users || 0,
      conversions: (metrics as any).conversions || 0,
      growthRate: `${(metrics as any).growthRate || "0"}%`,
    } : null
  );

  if (isLoading || !metrics) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
          >
            <Card className="p-6 overflow-hidden relative">
              <CardContent className="p-0">
                <div className="flex items-center justify-between mb-4">
                  <LoadingSkeleton variant="avatar" className="h-12 w-12" />
                  <LoadingSkeleton variant="button" className="h-6 w-16" />
                </div>
                <LoadingSkeleton variant="text" className="h-4 w-24 mb-2" />
                <LoadingSkeleton variant="text" className="h-8 w-32 mb-1" />
                <LoadingSkeleton variant="text" className="h-3 w-20" />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    );
  }

  const metricsData = [
    {
      key: "revenue",
      title: "Total Revenue",
      value: realtimeMetrics?.revenue || `$${parseFloat((metrics as any)?.revenue || "0").toLocaleString()}`,
      change: "+12.5%",
      subtitle: "vs last month",
    },
    {
      key: "users",
      title: "Active Users",
      value: realtimeMetrics?.users?.toLocaleString() || ((metrics as any)?.users || 0).toLocaleString(),
      change: "+8.3%",
      subtitle: "this month",
    },
    {
      key: "conversions",
      title: "Conversions",
      value: realtimeMetrics?.conversions?.toLocaleString() || ((metrics as any)?.conversions || 0).toLocaleString(),
      change: "+15.8%",
      subtitle: "this period",
    },    
    {
      key: "growth",
      title: "Growth Rate",
      value: realtimeMetrics?.growthRate || `${parseFloat((metrics as any)?.growthRate || "0")}%`,
      change: "+22.1%",
      subtitle: "year over year",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metricsData.map((metric, index) => {
        const Icon = metricIcons[metric.key as keyof typeof metricIcons];
        const colorClass = metricColors[metric.key as keyof typeof metricColors];

        return (
          <motion.div
            key={metric.key}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ 
              duration: 0.5, 
              delay: index * 0.1,
              type: "spring",
              stiffness: 100
            }}
            whileHover={{ 
              y: -8, 
              transition: { duration: 0.2 } 
            }}
            whileTap={{ scale: 0.98 }}
          >
            <Card className="hover:shadow-2xl hover:shadow-primary/10 transition-all duration-500 group cursor-pointer border-0 bg-gradient-to-br from-white to-gray-50 dark:from-slate-800 dark:to-slate-900 overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <CardContent className="p-6 relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <motion.div 
                    className={`p-3 rounded-xl ${colorClass} group-hover:scale-110 transition-transform duration-300`}
                    whileHover={{ rotate: 5 }}
                  >
                    <Icon className="text-xl" />
                  </motion.div>
                  
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 + 0.3 }}
                    className={`flex items-center text-sm font-semibold px-3 py-1 rounded-full ${colorClass} group-hover:animate-bounce-subtle`}
                  >
                    <ArrowUpRight className="w-3 h-3 mr-1" />
                    {metric.change}
                  </motion.div>
                </div>

                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.1 + 0.2 }}
                >
                  <h3 className="text-gray-600 dark:text-gray-400 text-sm font-medium mb-2 tracking-wide uppercase">
                    {metric.title}
                  </h3>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 + 0.4 }}
                  className="text-4xl font-bold text-gray-900 dark:text-white mb-2 font-mono tracking-tight group-hover:text-primary transition-colors duration-300"
                >
                  {metric.key === "revenue" ? (
                    <AnimatedCounter 
                      value={parseFloat(metric.value.replace(/[$,]/g, "") || "0")} 
                      duration={1}
                      prefix="$"
                    />
                  ) : metric.key === "growth" ? (
                    <AnimatedCounter 
                      value={parseFloat(metric.value.replace("%", "") || "0")} 
                      duration={1}
                      suffix="%"
                    />
                  ) : (
                    <AnimatedCounter 
                      value={parseInt(metric.value.replace(/,/g, "") || "0")} 
                      duration={1}
                    />
                  )}
                </motion.div>

                <motion.p 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.1 + 0.5 }}
                  className="text-gray-500 dark:text-gray-400 text-sm group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors duration-300"
                >
                  {metric.subtitle}
                </motion.p>

                {/* Animated background pattern */}
                <motion.div
                  className="absolute -top-10 -right-10 w-20 h-20 bg-gradient-to-br from-primary/10 to-purple-500/10 rounded-full opacity-0 group-hover:opacity-100"
                  animate={{ 
                    rotate: 360,
                    scale: [1, 1.2, 1]
                  }}
                  transition={{ 
                    rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                    scale: { duration: 4, repeat: Infinity, ease: "easeInOut" }
                  }}
                />
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}
