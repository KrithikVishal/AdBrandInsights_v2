import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { Download, FileImage, FileText, Link, Copy, Check } from "lucide-react";
import { useState } from "react";
import html2canvas from "html2canvas";
import { exportToPDF } from "@/lib/export-utils";

interface ExportManagerProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (toast: any) => void;
}

export function ExportManager({ isOpen, onClose, onShowToast }: ExportManagerProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  const [urlCopied, setUrlCopied] = useState(false);

  const handleScreenshotExport = async () => {
    setIsExporting(true);
    try {
      const element = document.querySelector('[data-dashboard-content]') as HTMLElement;
      if (!element) {
        throw new Error('Dashboard content not found');
      }

      const canvas = await html2canvas(element, {
        backgroundColor: '#ffffff',
        scale: 2,
        useCORS: true,
        allowTaint: true
      });

      const link = document.createElement('a');
      link.download = `dashboard-snapshot-${new Date().getTime()}.png`;
      link.href = canvas.toDataURL();
      link.click();

      onShowToast({
        id: `export-${Date.now()}`,
        type: "success",
        title: "Screenshot Downloaded!",
        description: "Your dashboard snapshot has been saved successfully.",
        duration: 3000
      });

      onClose();
    } catch (error) {
      onShowToast({
        id: `error-${Date.now()}`,
        type: "error",
        title: "Export Failed",
        description: "Unable to capture screenshot. Please try again.",
        duration: 5000
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handlePDFExport = async () => {
    setIsExporting(true);
    try {
      // Get sample data for PDF export
      const dashboardData = {
        metrics: {
          revenue: "$892,430",
          users: "24,563",
          conversions: "3,247",
          growth: "43.2%"
        },
        charts: [],
        campaigns: []
      };

      exportToPDF(dashboardData, "dashboard-report");
      
      onShowToast({
        id: `pdf-${Date.now()}`,
        type: "success",
        title: "PDF Downloaded!",
        description: "Your dashboard report has been generated successfully.",
        duration: 3000
      });

      onClose();
    } catch (error) {
      onShowToast({
        id: `pdf-error-${Date.now()}`,
        type: "error",
        title: "PDF Export Failed",
        description: "Unable to generate PDF report. Please try again.",
        duration: 5000
      });
    } finally {
      setIsExporting(false);
    }
  };

  const generateShareUrl = () => {
    const baseUrl = window.location.origin;
    const shareId = Math.random().toString(36).substring(2, 15);
    const url = `${baseUrl}/shared/${shareId}`;
    setShareUrl(url);
    
    onShowToast({
      id: `share-${Date.now()}`,
      type: "info",
      title: "Share Link Generated",
      description: "Your dashboard share link is ready to copy.",
      duration: 4000
    });
  };

  const copyShareUrl = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setUrlCopied(true);
      
      onShowToast({
        id: `copy-${Date.now()}`,
        type: "success",
        title: "Link Copied!",
        description: "Share link has been copied to your clipboard.",
        duration: 3000,
        action: {
          label: "View Link",
          onClick: () => window.open(shareUrl, '_blank')
        }
      });

      setTimeout(() => setUrlCopied(false), 2000);
    } catch (error) {
      onShowToast({
        id: `copy-error-${Date.now()}`,
        type: "error",
        title: "Copy Failed",
        description: "Unable to copy link. Please copy manually.",
        duration: 4000
      });
    }
  };

  const exportOptions = [
    {
      id: "screenshot",
      title: "Screenshot (PNG)",
      description: "High-quality image of your dashboard",
      icon: FileImage,
      color: "from-blue-500 to-indigo-600",
      onClick: handleScreenshotExport
    },
    {
      id: "pdf",
      title: "PDF Report",
      description: "Comprehensive dashboard report",
      icon: FileText,
      color: "from-red-500 to-rose-600",
      onClick: handlePDFExport
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
            onClick={onClose}
          />
          
          {/* Export Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed inset-0 flex items-center justify-center z-50 p-4"
          >
            <Card className="w-full max-w-md bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl border-0 shadow-2xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <motion.div
                      className="p-2 rounded-lg bg-gradient-to-r from-primary to-purple-600 text-white"
                      animate={{ rotate: [0, 360] }}
                      transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    >
                      <Download className="w-5 h-5" />
                    </motion.div>
                    <div>
                      <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                        Export & Share
                      </h2>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Download or share your dashboard
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onClose}
                    className="rounded-full"
                  >
                    ×
                  </Button>
                </div>

                {/* Export Options */}
                <div className="space-y-3 mb-6">
                  {exportOptions.map((option, index) => {
                    const Icon = option.icon;
                    
                    return (
                      <motion.div
                        key={option.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="p-4 rounded-xl border border-gray-200 dark:border-slate-700 hover:border-primary/50 transition-all duration-300 cursor-pointer group"
                        onClick={option.onClick}
                        whileHover={{ scale: 1.02, y: -2 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <div className="flex items-center space-x-3">
                          <motion.div
                            className={`p-2 rounded-lg bg-gradient-to-r ${option.color} text-white group-hover:scale-110 transition-transform`}
                            whileHover={{ rotate: 10 }}
                          >
                            <Icon className="w-4 h-4" />
                          </motion.div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 dark:text-white">
                              {option.title}
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {option.description}
                            </p>
                          </div>
                          {isExporting && (
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full"
                            />
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Share Section */}
                <div className="border-t border-gray-200 dark:border-slate-700 pt-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Link className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                    <h3 className="font-semibold text-gray-900 dark:text-white">
                      Live Share
                    </h3>
                  </div>
                  
                  {!shareUrl ? (
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button
                        onClick={generateShareUrl}
                        variant="outline"
                        className="w-full"
                      >
                        Generate Share Link
                      </Button>
                    </motion.div>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-3"
                    >
                      <div className="p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
                        <p className="text-xs text-gray-600 dark:text-gray-400 mb-1">
                          Share URL:
                        </p>
                        <p className="text-sm font-mono text-gray-900 dark:text-white break-all">
                          {shareUrl}
                        </p>
                      </div>
                      
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Button
                          onClick={copyShareUrl}
                          className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90"
                        >
                          <AnimatePresence mode="wait">
                            {urlCopied ? (
                              <motion.div
                                key="copied"
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                exit={{ scale: 0 }}
                                className="flex items-center space-x-2"
                              >
                                <Check className="w-4 h-4" />
                                <span>Copied!</span>
                              </motion.div>
                            ) : (
                              <motion.div
                                key="copy"
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                exit={{ scale: 0 }}
                                className="flex items-center space-x-2"
                              >
                                <Copy className="w-4 h-4" />
                                <span>Copy Link</span>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </Button>
                      </motion.div>
                    </motion.div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

export function ExportTrigger({ onOpen }: { onOpen: () => void }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <Button
        onClick={onOpen}
        variant="outline"
        className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm hover:bg-white dark:hover:bg-slate-800 border-gray-200 dark:border-slate-700"
      >
        <Download className="w-4 h-4 mr-2" />
        Export
      </Button>
    </motion.div>
  );
}