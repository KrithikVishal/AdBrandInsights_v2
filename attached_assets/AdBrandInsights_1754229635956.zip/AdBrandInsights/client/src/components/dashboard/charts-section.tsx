import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { Download, TrendingUp, BarChart3, PieChart as PieChartIcon } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { exportToPDF } from "@/lib/export-utils";
import { useTheme } from "@/components/theme-provider";
import { LoadingSkeleton } from "@/components/ui/loading-skeleton";

const trafficSourcesData = [
  { source: "Google Ads", percentage: 35, color: "#6366f1" },
  { source: "Facebook", percentage: 25, color: "#8b5cf6" },
  { source: "LinkedIn", percentage: 20, color: "#ec4899" },
  { source: "Direct", percentage: 15, color: "#10b981" },
  { source: "Other", percentage: 5, color: "#f59e0b" },
];

const campaignData = [
  { campaign: "Summer Sale", ctr: 1.47, color: "#6366f1" },
  { campaign: "Brand Awareness", ctr: 1.58, color: "#8b5cf6" },
  { campaign: "Product Launch", ctr: 2.32, color: "#ec4899" },
  { campaign: "Retargeting", ctr: 1.54, color: "#10b981" },
  { campaign: "Holiday Campaign", ctr: 1.89, color: "#f59e0b" },
];

export function ChartsSection() {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const { data: revenueData, isLoading: revenueLoading } = useQuery({
    queryKey: ["/api/charts/revenue-trend"],
  });

  const { data: trafficSources, isLoading: trafficLoading } = useQuery({
    queryKey: ["/api/traffic-sources"],
  });

  const handleExport = () => {
    exportToPDF({ revenueData, trafficSources }, "charts-data");
  };

  const ChartSkeleton = () => (
    <motion.div 
      className="space-y-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <LoadingSkeleton variant="text" className="h-4 w-1/3" />
      <LoadingSkeleton variant="card" className="h-[300px] w-full rounded-xl" />
    </motion.div>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Revenue Trend Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, type: "spring", stiffness: 100 }}
        whileHover={{ y: -4 }}
      >
        <Card className="transition-all duration-500 hover:shadow-2xl hover:shadow-primary/5 border-0 bg-gradient-to-br from-white to-gray-50 dark:from-slate-800 dark:to-slate-900 overflow-hidden group">
          <CardHeader className="relative">
            <motion.div 
              className="flex items-center justify-between"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="flex items-center space-x-3">
                <motion.div
                  className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400"
                  whileHover={{ rotate: 5, scale: 1.1 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <TrendingUp className="w-5 h-5" />
                </motion.div>
                <div>
                  <CardTitle className="text-lg font-semibold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                    Revenue Trend
                  </CardTitle>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    Monthly revenue over time
                  </p>
                </div>
              </div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={handleExport}
                  className="hover:bg-primary/10 hover:text-primary transition-colors duration-300"
                >
                  <Download className="h-4 w-4" />
                </Button>
              </motion.div>
            </motion.div>
            
            {/* Animated background gradient */}
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </CardHeader>
          <CardContent>
            {revenueLoading ? (
              <ChartSkeleton />
            ) : (
              <div className="chart-container">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={(revenueData as any[]) || []}>
                    <CartesianGrid 
                      strokeDasharray="3 3" 
                      stroke={isDark ? "#334155" : "#e5e7eb"} 
                    />
                    <XAxis 
                      dataKey="month" 
                      stroke={isDark ? "#e2e8f0" : "#374151"}
                    />
                    <YAxis 
                      stroke={isDark ? "#e2e8f0" : "#374151"}
                      tickFormatter={(value) => `$${(value / 1000)}K`}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: isDark ? "#1e293b" : "#ffffff",
                        border: `1px solid ${isDark ? "#334155" : "#e5e7eb"}`,
                        borderRadius: "8px",
                        color: isDark ? "#e2e8f0" : "#374151",
                      }}
                      formatter={(value: number) => [`$${value.toLocaleString()}`, "Revenue"]}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="revenue" 
                      stroke="#6366f1" 
                      strokeWidth={3}
                      dot={{ fill: "#6366f1", strokeWidth: 2, r: 6 }}
                      activeDot={{ r: 8, stroke: "#6366f1", strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Traffic Sources Donut Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, type: "spring", stiffness: 100 }}
        whileHover={{ y: -4 }}
      >
        <Card className="transition-all duration-500 hover:shadow-2xl hover:shadow-primary/5 border-0 bg-gradient-to-br from-white to-gray-50 dark:from-slate-800 dark:to-slate-900 overflow-hidden group">
          <CardHeader className="relative">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="flex items-center space-x-3"
            >
              <motion.div
                className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400"
                whileHover={{ rotate: 5, scale: 1.1 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <PieChartIcon className="w-5 h-5" />
              </motion.div>
              <div>
                <CardTitle className="text-lg font-semibold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                  Traffic Sources
                </CardTitle>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  Where your visitors come from
                </p>
              </div>
            </motion.div>
            
            {/* Animated background gradient */}
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </CardHeader>
          <CardContent>
            {trafficLoading ? (
              <ChartSkeleton />
            ) : (
              <div className="chart-container">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={trafficSourcesData}
                      cx="50%"
                      cy="50%"
                      innerRadius={80}
                      outerRadius={120}
                      paddingAngle={2}
                      dataKey="percentage"
                    >
                      {trafficSourcesData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: isDark ? "#1e293b" : "#ffffff",
                        border: `1px solid ${isDark ? "#334155" : "#e5e7eb"}`,
                        borderRadius: "8px",
                        color: isDark ? "#e2e8f0" : "#374151",
                      }}
                      formatter={(value: number, name: string) => [`${value}%`, name]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Campaign Performance Bar Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="lg:col-span-2"
      >
        <Card className="transition-all duration-300 animate-slide-up">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg font-semibold">Campaign Performance</CardTitle>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  Click-through rates by campaign
                </p>
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Campaigns</SelectItem>
                  <SelectItem value="active">Active Only</SelectItem>
                  <SelectItem value="paused">Paused</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="chart-container">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={campaignData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid 
                    strokeDasharray="3 3" 
                    stroke={isDark ? "#334155" : "#e5e7eb"} 
                  />
                  <XAxis 
                    dataKey="campaign" 
                    stroke={isDark ? "#e2e8f0" : "#374151"}
                  />
                  <YAxis 
                    stroke={isDark ? "#e2e8f0" : "#374151"}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: isDark ? "#1e293b" : "#ffffff",
                      border: `1px solid ${isDark ? "#334155" : "#e5e7eb"}`,
                      borderRadius: "8px",
                      color: isDark ? "#e2e8f0" : "#374151",
                    }}
                    formatter={(value: number) => [`${value}%`, "CTR"]}
                  />
                  <Bar 
                    dataKey="ctr" 
                    radius={[8, 8, 0, 0]}
                    fill="#6366f1"
                  >
                    {campaignData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
