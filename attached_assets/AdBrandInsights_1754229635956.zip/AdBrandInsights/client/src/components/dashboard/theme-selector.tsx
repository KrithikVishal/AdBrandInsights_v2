import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Palette, Check } from "lucide-react";
import { useState, useEffect } from "react";

interface Theme {
  id: string;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  preview: string;
}

const themes: Theme[] = [
  {
    id: "default",
    name: "Ocean Blue",
    colors: { primary: "214 82% 51%", secondary: "210 40% 98%", accent: "142 76% 36%" },
    preview: "from-blue-500 to-indigo-600"
  },
  {
    id: "sunset",
    name: "Sunset Orange",
    colors: { primary: "20 82% 51%", secondary: "20 40% 98%", accent: "28 76% 46%" },
    preview: "from-orange-500 to-red-600"
  },
  {
    id: "forest",
    name: "Forest Green",
    colors: { primary: "142 82% 41%", secondary: "138 40% 98%", accent: "160 76% 36%" },
    preview: "from-green-500 to-emerald-600"
  },
  {
    id: "royal",
    name: "Royal Purple",
    colors: { primary: "262 82% 51%", secondary: "260 40% 98%", accent: "280 76% 46%" },
    preview: "from-purple-500 to-violet-600"
  },
  {
    id: "rose",
    name: "Rose Pink",
    colors: { primary: "330 82% 51%", secondary: "328 40% 98%", accent: "345 76% 46%" },
    preview: "from-pink-500 to-rose-600"
  },
  {
    id: "cyber",
    name: "Cyber Teal",
    colors: { primary: "174 82% 51%", secondary: "172 40% 98%", accent: "185 76% 36%" },
    preview: "from-teal-500 to-cyan-600"
  }
];

interface ThemeSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onThemeChange: (themeId: string) => void;
}

export function ThemeSelector({ isOpen, onClose, onThemeChange }: ThemeSelectorProps) {
  const [selectedTheme, setSelectedTheme] = useState("default");

  useEffect(() => {
    const savedTheme = localStorage.getItem("admybrand-color-theme") || "default";
    setSelectedTheme(savedTheme);
    applyTheme(themes.find(t => t.id === savedTheme) || themes[0]);
  }, []);

  const applyTheme = (theme: Theme) => {
    const root = document.documentElement;
    root.style.setProperty("--primary", theme.colors.primary);
    root.style.setProperty("--secondary", theme.colors.secondary);
    root.style.setProperty("--accent", theme.colors.accent);
  };

  const handleThemeSelect = (theme: Theme) => {
    setSelectedTheme(theme.id);
    applyTheme(theme);
    localStorage.setItem("admybrand-color-theme", theme.id);
    onThemeChange(theme.id);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
            onClick={onClose}
          />
          
          {/* Theme Selector Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed inset-0 flex items-center justify-center z-50 p-4"
          >
            <Card className="w-full max-w-2xl max-h-[80vh] overflow-y-auto bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl border-0 shadow-2xl">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <motion.div
                      className="p-2 rounded-lg bg-gradient-to-r from-primary to-purple-600 text-white"
                      animate={{ rotate: [0, 360] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    >
                      <Palette className="w-5 h-5" />
                    </motion.div>
                    <div>
                      <CardTitle className="text-xl font-bold">Choose Your Theme</CardTitle>
                      <p className="text-gray-600 dark:text-gray-400 text-sm">
                        Customize the look and feel of your dashboard
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={onClose}
                    className="rounded-full"
                  >
                    ×
                  </Button>
                </div>
              </CardHeader>

              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {themes.map((theme, index) => (
                    <motion.div
                      key={theme.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`relative p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                        selectedTheme === theme.id
                          ? 'border-primary bg-primary/5'
                          : 'border-gray-200 dark:border-slate-700 hover:border-primary/50 hover:bg-primary/5'
                      }`}
                      onClick={() => handleThemeSelect(theme)}
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      {/* Theme Preview */}
                      <div className={`w-full h-20 rounded-lg bg-gradient-to-r ${theme.preview} mb-3 relative overflow-hidden`}>
                        <div className="absolute inset-0 bg-white/20 backdrop-blur-sm" />
                        <div className="absolute top-2 right-2 w-4 h-4 bg-white/30 rounded-full" />
                        <div className="absolute bottom-2 left-2 space-y-1">
                          <div className="w-8 h-1 bg-white/50 rounded" />
                          <div className="w-12 h-1 bg-white/30 rounded" />
                        </div>
                      </div>

                      {/* Theme Info */}
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white">
                            {theme.name}
                          </h3>
                          <div className="flex space-x-1 mt-1">
                            <div 
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: `hsl(${theme.colors.primary})` }}
                            />
                            <div 
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: `hsl(${theme.colors.accent})` }}
                            />
                          </div>
                        </div>
                        
                        {selectedTheme === theme.id && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="p-1 rounded-full bg-primary text-white"
                          >
                            <Check className="w-4 h-4" />
                          </motion.div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>

                <motion.div 
                  className="mt-6 flex justify-end space-x-3"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                >
                  <Button variant="outline" onClick={onClose}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={onClose}
                    className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90"
                  >
                    Apply Theme
                  </Button>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

export function ThemeTrigger({ onOpen }: { onOpen: () => void }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <Button
        onClick={onOpen}
        variant="outline"
        size="icon"
        className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm hover:bg-white dark:hover:bg-slate-800 border-gray-200 dark:border-slate-700"
      >
        <Palette className="w-4 h-4" />
      </Button>
    </motion.div>
  );
}