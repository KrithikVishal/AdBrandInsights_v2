import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { Filter, X, Calendar, MapPin, Smartphone, Target, Search } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";

interface FilterState {
  campaignTypes: string[];
  geography: string[];
  devices: string[];
  dateRange: string;
  searchTerm: string;
}

const filterOptions = {
  campaignTypes: [
    { id: "google-ads", label: "Google Ads", count: 24 },
    { id: "facebook", label: "Facebook", count: 18 },
    { id: "instagram", label: "Instagram", count: 12 },
    { id: "youtube", label: "YouTube", count: 8 },
    { id: "tiktok", label: "TikTok", count: 6 },
    { id: "linkedin", label: "LinkedIn", count: 4 }
  ],
  geography: [
    { id: "north-america", label: "North America", count: 45 },
    { id: "europe", label: "Europe", count: 32 },
    { id: "asia-pacific", label: "Asia Pacific", count: 28 },
    { id: "south-america", label: "South America", count: 15 },
    { id: "middle-east", label: "Middle East", count: 12 },
    { id: "africa", label: "Africa", count: 8 }
  ],
  devices: [
    { id: "mobile", label: "Mobile", count: 58 },
    { id: "desktop", label: "Desktop", count: 35 },
    { id: "tablet", label: "Tablet", count: 12 }
  ]
};

interface InteractiveFiltersProps {
  isOpen: boolean;
  onClose: () => void;
  onFiltersChange: (filters: FilterState) => void;
}

export function InteractiveFilters({ isOpen, onClose, onFiltersChange }: InteractiveFiltersProps) {
  const [filters, setFilters] = useState<FilterState>({
    campaignTypes: [],
    geography: [],
    devices: [],
    dateRange: "30days",
    searchTerm: ""
  });

  const [activeTab, setActiveTab] = useState<"campaigns" | "geography" | "devices">("campaigns");

  const handleFilterChange = (category: keyof FilterState, value: string | string[]) => {
    const newFilters = { ...filters, [category]: value };
    setFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const toggleFilter = (category: "campaignTypes" | "geography" | "devices", value: string) => {
    const currentValues = filters[category];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    handleFilterChange(category, newValues);
  };

  const clearAllFilters = () => {
    const emptyFilters = {
      campaignTypes: [],
      geography: [],
      devices: [],
      dateRange: "30days",
      searchTerm: ""
    };
    setFilters(emptyFilters);
    onFiltersChange(emptyFilters);
  };

  const totalActiveFilter = filters.campaignTypes.length + filters.geography.length + filters.devices.length;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
            onClick={onClose}
          />
          
          {/* Filter Panel */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed right-0 top-0 h-full w-96 bg-white dark:bg-slate-800 shadow-2xl z-50 overflow-hidden"
          >
            <div className="flex flex-col h-full">
              {/* Header */}
              <motion.div 
                className="p-6 border-b border-gray-200 dark:border-slate-700 bg-gradient-to-r from-primary/5 to-purple-500/5"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <motion.div
                      className="p-2 rounded-lg bg-gradient-to-r from-primary to-purple-600 text-white"
                      whileHover={{ rotate: 10, scale: 1.1 }}
                      transition={{ type: "spring", stiffness: 400 }}
                    >
                      <Filter className="w-5 h-5" />
                    </motion.div>
                    <div>
                      <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Advanced Filters</h2>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {totalActiveFilter} active filters
                      </p>
                    </div>
                  </div>
                  <motion.button
                    onClick={onClose}
                    className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                  </motion.button>
                </div>
              </motion.div>

              {/* Search */}
              <motion.div 
                className="p-4 border-b border-gray-200 dark:border-slate-700"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search campaigns, keywords..."
                    value={filters.searchTerm}
                    onChange={(e) => handleFilterChange("searchTerm", e.target.value)}
                    className="pl-10 bg-gray-50 dark:bg-slate-700 border-gray-200 dark:border-slate-600"
                  />
                </div>
              </motion.div>

              {/* Date Range */}
              <motion.div 
                className="p-4 border-b border-gray-200 dark:border-slate-700"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <div className="flex items-center space-x-2 mb-3">
                  <Calendar className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Date Range</span>
                </div>
                <Select value={filters.dateRange} onValueChange={(value) => handleFilterChange("dateRange", value)}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7days">Last 7 days</SelectItem>
                    <SelectItem value="30days">Last 30 days</SelectItem>
                    <SelectItem value="90days">Last 90 days</SelectItem>
                    <SelectItem value="1year">Last year</SelectItem>
                    <SelectItem value="custom">Custom range</SelectItem>
                  </SelectContent>
                </Select>
              </motion.div>

              {/* Filter Tabs */}
              <motion.div 
                className="flex border-b border-gray-200 dark:border-slate-700"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                {[
                  { id: "campaigns", label: "Campaigns", icon: Target },
                  { id: "geography", label: "Geography", icon: MapPin },
                  { id: "devices", label: "Devices", icon: Smartphone }
                ].map((tab) => (
                  <motion.button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex-1 flex items-center justify-center space-x-2 p-3 text-sm font-medium transition-colors ${
                      activeTab === tab.id
                        ? "bg-primary/10 text-primary border-b-2 border-primary"
                        : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                    }`}
                    whileHover={{ y: -1 }}
                    whileTap={{ y: 0 }}
                  >
                    <tab.icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </motion.button>
                ))}
              </motion.div>

              {/* Filter Content */}
              <div className="flex-1 overflow-y-auto p-4">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                    className="space-y-3"
                  >
                    {filterOptions[activeTab as keyof typeof filterOptions].map((option, index) => (
                      <motion.div
                        key={option.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors cursor-pointer group"
                        onClick={() => toggleFilter(activeTab as any, option.id)}
                      >
                        <div className="flex items-center space-x-3">
                          <Checkbox
                            checked={filters[activeTab as keyof FilterState].includes(option.id)}
                            className="group-hover:scale-110 transition-transform"
                          />
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {option.label}
                          </span>
                        </div>
                        <motion.div
                          className="bg-gray-200 dark:bg-slate-600 text-gray-600 dark:text-gray-400 px-2 py-1 rounded-full text-xs font-medium"
                          whileHover={{ scale: 1.05 }}
                        >
                          {option.count}
                        </motion.div>
                      </motion.div>
                    ))}
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Active Filters & Actions */}
              <motion.div 
                className="p-4 border-t border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-700/50"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                {totalActiveFilter > 0 && (
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Active Filters</span>
                      <motion.button
                        onClick={clearAllFilters}
                        className="text-xs text-red-600 dark:text-red-400 hover:underline"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        Clear all
                      </motion.button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {([...filters.campaignTypes, ...filters.geography, ...filters.devices] as string[]).map((filter, index) => (
                        <motion.div
                          key={filter}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                            {filterOptions.campaignTypes.find(opt => opt.id === filter)?.label ||
                             filterOptions.geography.find(opt => opt.id === filter)?.label ||
                             filterOptions.devices.find(opt => opt.id === filter)?.label}
                          </Badge>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="flex space-x-3">
                  <motion.div className="flex-1" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button onClick={onClose} className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90">
                      Apply Filters
                    </Button>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button variant="outline" onClick={clearAllFilters}>
                      Reset
                    </Button>
                  </motion.div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

export function FilterTrigger({ onOpen, filterCount = 0 }: { onOpen: () => void; filterCount?: number }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <Button
        onClick={onOpen}
        variant="outline"
        className="relative bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm hover:bg-white dark:hover:bg-slate-800 border-gray-200 dark:border-slate-700"
      >
        <Filter className="w-4 h-4 mr-2" />
        Filters
        {filterCount > 0 && (
          <motion.span
            className="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 500 }}
          >
            {filterCount}
          </motion.span>
        )}
      </Button>
    </motion.div>
  );
}