import { useEffect, useState } from "react";
import { updateMetricsWithVariation } from "@/lib/mock-data";

export function useRealTimeMetrics(baseMetrics: any, intervalMs: number = 30000) {
  const [metrics, setMetrics] = useState(baseMetrics);

  useEffect(() => {
    if (!baseMetrics) return;

    const interval = setInterval(() => {
      setMetrics((prev: any) => ({
        ...prev,
        revenue: updateMetricsWithVariation(parseInt(prev.revenue.replace(/[$,]/g, ""))).toLocaleString(),
        users: updateMetricsWithVariation(prev.users),
        conversions: updateMetricsWithVariation(prev.conversions),
        growthRate: (parseFloat(prev.growthRate) + (Math.random() - 0.5) * 2).toFixed(1),
      }));
    }, intervalMs);

    return () => clearInterval(interval);
  }, [baseMetrics, intervalMs]);

  return metrics;
}
